--
-- PostgreSQL database dump
--

-- Dumped from database version 16.8 (Ubuntu 16.8-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.8 (Ubuntu 16.8-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Booking; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Booking" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "shopId" integer NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    hour integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "availabilityId" integer NOT NULL
);


ALTER TABLE public."Booking" OWNER TO postgres;

--
-- Name: Booking_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Booking_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Booking_id_seq" OWNER TO postgres;

--
-- Name: Booking_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Booking_id_seq" OWNED BY public."Booking".id;


--
-- Name: Config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Config" (
    key text NOT NULL,
    value text NOT NULL
);


ALTER TABLE public."Config" OWNER TO postgres;

--
-- Name: Conversation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Conversation" (
    id integer NOT NULL,
    "user1Id" integer NOT NULL,
    "user2Id" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Conversation" OWNER TO postgres;

--
-- Name: Conversation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Conversation_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Conversation_id_seq" OWNER TO postgres;

--
-- Name: Conversation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Conversation_id_seq" OWNED BY public."Conversation".id;


--
-- Name: FriendRequest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."FriendRequest" (
    id integer NOT NULL,
    "senderId" integer NOT NULL,
    "receiverId" integer NOT NULL,
    status text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."FriendRequest" OWNER TO postgres;

--
-- Name: FriendRequest_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."FriendRequest_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."FriendRequest_id_seq" OWNER TO postgres;

--
-- Name: FriendRequest_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."FriendRequest_id_seq" OWNED BY public."FriendRequest".id;


--
-- Name: Inventory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Inventory" (
    id integer NOT NULL,
    name text NOT NULL,
    quantity integer NOT NULL,
    price double precision NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "shopId" integer,
    "userId" integer
);


ALTER TABLE public."Inventory" OWNER TO postgres;

--
-- Name: Inventory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Inventory_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Inventory_id_seq" OWNER TO postgres;

--
-- Name: Inventory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Inventory_id_seq" OWNED BY public."Inventory".id;


--
-- Name: Job; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Job" (
    id integer NOT NULL,
    "jobId" text NOT NULL,
    status text NOT NULL,
    result jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Job" OWNER TO postgres;

--
-- Name: Job_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Job_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Job_id_seq" OWNER TO postgres;

--
-- Name: Job_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Job_id_seq" OWNED BY public."Job".id;


--
-- Name: Log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Log" (
    id integer NOT NULL,
    message text NOT NULL,
    level text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Log" OWNER TO postgres;

--
-- Name: Log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Log_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Log_id_seq" OWNER TO postgres;

--
-- Name: Log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Log_id_seq" OWNED BY public."Log".id;


--
-- Name: Message; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Message" (
    id integer NOT NULL,
    "conversationId" integer NOT NULL,
    "userId" integer NOT NULL,
    content text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Message" OWNER TO postgres;

--
-- Name: Message_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Message_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Message_id_seq" OWNER TO postgres;

--
-- Name: Message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Message_id_seq" OWNED BY public."Message".id;


--
-- Name: Otp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Otp" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    otp text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Otp" OWNER TO postgres;

--
-- Name: Otp_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Otp_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Otp_id_seq" OWNER TO postgres;

--
-- Name: Otp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Otp_id_seq" OWNED BY public."Otp".id;


--
-- Name: Product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Product" (
    id integer NOT NULL,
    name text NOT NULL,
    price double precision NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Product" OWNER TO postgres;

--
-- Name: Product_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Product_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Product_id_seq" OWNER TO postgres;

--
-- Name: Product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Product_id_seq" OWNED BY public."Product".id;


--
-- Name: Roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Roles" (
    id integer NOT NULL,
    name text NOT NULL
);


ALTER TABLE public."Roles" OWNER TO postgres;

--
-- Name: Roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Roles_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Roles_id_seq" OWNER TO postgres;

--
-- Name: Roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Roles_id_seq" OWNED BY public."Roles".id;


--
-- Name: Session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Session" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    token text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "refreshToken" text
);


ALTER TABLE public."Session" OWNER TO postgres;

--
-- Name: Session_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Session_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Session_id_seq" OWNER TO postgres;

--
-- Name: Session_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Session_id_seq" OWNED BY public."Session".id;


--
-- Name: Shop; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Shop" (
    id integer NOT NULL,
    name text NOT NULL,
    location text NOT NULL
);


ALTER TABLE public."Shop" OWNER TO postgres;

--
-- Name: ShopAvailability; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ShopAvailability" (
    id integer NOT NULL,
    "shopId" integer NOT NULL,
    "timeSlotId" integer NOT NULL
);


ALTER TABLE public."ShopAvailability" OWNER TO postgres;

--
-- Name: ShopAvailability_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ShopAvailability_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ShopAvailability_id_seq" OWNER TO postgres;

--
-- Name: ShopAvailability_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ShopAvailability_id_seq" OWNED BY public."ShopAvailability".id;


--
-- Name: Shop_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Shop_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Shop_id_seq" OWNER TO postgres;

--
-- Name: Shop_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Shop_id_seq" OWNED BY public."Shop".id;


--
-- Name: TimeSlot; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."TimeSlot" (
    id integer NOT NULL,
    hour integer NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    "shopId" integer NOT NULL,
    minute integer NOT NULL
);


ALTER TABLE public."TimeSlot" OWNER TO postgres;

--
-- Name: TimeSlot_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."TimeSlot_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."TimeSlot_id_seq" OWNER TO postgres;

--
-- Name: TimeSlot_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."TimeSlot_id_seq" OWNED BY public."TimeSlot".id;


--
-- Name: Upload; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Upload" (
    id text NOT NULL,
    type text NOT NULL,
    path text NOT NULL,
    "originalName" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    metadata jsonb
);


ALTER TABLE public."Upload" OWNER TO postgres;

--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    id integer NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    name text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "emailVerified" boolean DEFAULT false NOT NULL,
    "twoFactorSecret" text
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Name: User_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."User_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."User_id_seq" OWNER TO postgres;

--
-- Name: User_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."User_id_seq" OWNED BY public."User".id;


--
-- Name: _UserRoles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."_UserRoles" (
    "A" integer NOT NULL,
    "B" integer NOT NULL
);


ALTER TABLE public."_UserRoles" OWNER TO postgres;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: Booking id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Booking" ALTER COLUMN id SET DEFAULT nextval('public."Booking_id_seq"'::regclass);


--
-- Name: Conversation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Conversation" ALTER COLUMN id SET DEFAULT nextval('public."Conversation_id_seq"'::regclass);


--
-- Name: FriendRequest id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."FriendRequest" ALTER COLUMN id SET DEFAULT nextval('public."FriendRequest_id_seq"'::regclass);


--
-- Name: Inventory id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Inventory" ALTER COLUMN id SET DEFAULT nextval('public."Inventory_id_seq"'::regclass);


--
-- Name: Job id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Job" ALTER COLUMN id SET DEFAULT nextval('public."Job_id_seq"'::regclass);


--
-- Name: Log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Log" ALTER COLUMN id SET DEFAULT nextval('public."Log_id_seq"'::regclass);


--
-- Name: Message id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Message" ALTER COLUMN id SET DEFAULT nextval('public."Message_id_seq"'::regclass);


--
-- Name: Otp id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Otp" ALTER COLUMN id SET DEFAULT nextval('public."Otp_id_seq"'::regclass);


--
-- Name: Product id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Product" ALTER COLUMN id SET DEFAULT nextval('public."Product_id_seq"'::regclass);


--
-- Name: Roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Roles" ALTER COLUMN id SET DEFAULT nextval('public."Roles_id_seq"'::regclass);


--
-- Name: Session id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Session" ALTER COLUMN id SET DEFAULT nextval('public."Session_id_seq"'::regclass);


--
-- Name: Shop id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Shop" ALTER COLUMN id SET DEFAULT nextval('public."Shop_id_seq"'::regclass);


--
-- Name: ShopAvailability id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ShopAvailability" ALTER COLUMN id SET DEFAULT nextval('public."ShopAvailability_id_seq"'::regclass);


--
-- Name: TimeSlot id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TimeSlot" ALTER COLUMN id SET DEFAULT nextval('public."TimeSlot_id_seq"'::regclass);


--
-- Name: User id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User" ALTER COLUMN id SET DEFAULT nextval('public."User_id_seq"'::regclass);


--
-- Data for Name: Booking; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Booking" (id, "userId", "shopId", date, hour, "createdAt", "availabilityId") FROM stdin;
\.


--
-- Data for Name: Config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Config" (key, value) FROM stdin;
\.


--
-- Data for Name: Conversation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Conversation" (id, "user1Id", "user2Id", "createdAt", "updatedAt") FROM stdin;
1	1	2	2025-05-12 06:09:25.21	2025-05-12 06:09:25.21
\.


--
-- Data for Name: FriendRequest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."FriendRequest" (id, "senderId", "receiverId", status, "createdAt") FROM stdin;
1	1	2	accepted	2025-05-11 22:25:56.615
\.


--
-- Data for Name: Inventory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Inventory" (id, name, quantity, price, "createdAt", "updatedAt", "shopId", "userId") FROM stdin;
1	Sample Item	10	99.99	2025-05-14 15:25:14.348	2025-05-14 15:25:14.348	\N	\N
2	Sample Item	10	99.99	2025-05-14 15:37:27.123	2025-05-14 15:37:27.123	\N	\N
3	Sample Item	10	99.99	2025-05-14 15:38:59.722	2025-05-14 15:38:59.722	\N	\N
4	Sample Item	10	99.99	2025-05-14 15:44:34.09	2025-05-14 15:44:34.09	1	\N
5	Tomato	100	1.5	2025-05-16 15:33:31.246	2025-05-16 15:33:31.246	1	\N
6	Organic Carrot	50	2	2025-05-16 15:35:01.836	2025-05-16 15:35:01.836	\N	2
\.


--
-- Data for Name: Job; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Job" (id, "jobId", status, result, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Log" (id, message, level, "createdAt") FROM stdin;
\.


--
-- Data for Name: Message; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Message" (id, "conversationId", "userId", content, "createdAt") FROM stdin;
\.


--
-- Data for Name: Otp; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Otp" (id, "userId", otp, "expiresAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Product" (id, name, price, description, "createdAt") FROM stdin;
\.


--
-- Data for Name: Roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Roles" (id, name) FROM stdin;
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Session" (id, "userId", token, "createdAt", "refreshToken") FROM stdin;
\.


--
-- Data for Name: Shop; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Shop" (id, name, location) FROM stdin;
1	Test Shop	123 Main St
2	Test Shop	Downtown
3	Test Shop 3	Downtown
4	Test Shop 4	Downtown
5	Test Shop 5	Downtown
\.


--
-- Data for Name: ShopAvailability; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ShopAvailability" (id, "shopId", "timeSlotId") FROM stdin;
\.


--
-- Data for Name: TimeSlot; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."TimeSlot" (id, hour, date, "shopId", minute) FROM stdin;
154	7	2025-05-10 00:00:00	1	0
155	7	2025-05-10 00:00:00	1	30
156	8	2025-05-10 00:00:00	1	0
\.


--
-- Data for Name: Upload; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Upload" (id, type, path, "originalName", "createdAt", metadata) FROM stdin;
cmak5h91r0000uy2s03qehqor	avatar	/root/api/uploads/files/1746997959402-656301166.png	Screenshot_20250420-231614.png	2025-05-11 21:12:39.951	\N
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" (id, email, password, name, "createdAt", "emailVerified", "twoFactorSecret") FROM stdin;
2	sharifdarjenkyleabdulhamid@gmail.com	$2b$12$eJmWdU7DNwqdZDBSjGb4k.QHc7c0MjJMgpQWrQ2fiDJRYYehpDIV6	Second Account	2025-05-11 17:24:18.784	f	FJJCQO2SGVETAUTRIZ4SIRKYHFDGY2KU
1	warwar.tae@gmail.com	$2b$12$Syy/GDcqGIUsT/PBCbf.ueRce1XcpUhmdbhhwdkrOktArpupkNcV2	Sharif Ab	2025-05-06 17:11:11.759	f	OE6DUUZDLVXDAZ2MNNKDSNKHO5WUUNBX
\.


--
-- Data for Name: _UserRoles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."_UserRoles" ("A", "B") FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
13f6b140-58ae-473f-b75e-e9cd01d5285d	7ac4dc8d01112d135a97df68e628b718eb1a8d44a4321246b4ff1ffcb8bb0585	2025-05-07 01:10:56.667684+08	20250506142531_add_time_slot_id	\N	\N	2025-05-07 01:10:56.643181+08	1
b3c8ec96-1fbf-46c3-9f93-436fdf71ddd9	4a5679827818d9bb1b30fec2e1763627deedf4c21ed8dbf03ec90c2a2b3174e6	2025-05-07 01:10:56.028239+08	20250411153002_init	\N	\N	2025-05-07 01:10:55.987939+08	1
077a54f4-cc60-4cbc-a0f5-03fd5a50ed4e	834c7c93e035548d9f13148d9aa5866a186607da8f5b82ece1729a2c9fe2313b	2025-05-07 01:10:56.423538+08	20250501055014_add_session_model	\N	\N	2025-05-07 01:10:56.379422+08	1
211dd63c-2d27-49a6-aeec-378f998f24cc	10dd21cf5c23d0692c2b88a2d5c0dfb11f5b7fe3fb6b1f90a0db1367523ec56b	2025-05-07 01:10:56.06536+08	20250411161110_add_shop	\N	\N	2025-05-07 01:10:56.033065+08	1
17749e6f-aa29-4cfe-8d02-35f15fd4fe78	e76d36d6996d9ef73057dd62cdcbf7e66442c4bdc330d512428ffc6a1ba7f9cf	2025-05-07 01:10:56.103476+08	20250411181454_add_bookings_table	\N	\N	2025-05-07 01:10:56.070083+08	1
065bcbc9-94cc-4620-979e-3585f5c32cd7	756b0942a1e73d3233770611461b4648c2f56aef1257fac51f76fb3e643037c9	2025-05-07 01:10:56.122407+08	20250411183413_add_hour_to_booking	\N	\N	2025-05-07 01:10:56.108121+08	1
977e026b-dd23-4e40-bcd6-02225d8b50d2	36f14871b5967a04378c05986951211b19bbaf72dd21c994daff9724fad55fa8	2025-05-07 01:10:56.443525+08	20250501095951_add_email_verified	\N	\N	2025-05-07 01:10:56.428237+08	1
776e4292-80d4-412f-abbd-1535eba14bd9	2368958c961e1597703e26023649bf73cb5041fef25b52db8bbeb1ee64fd9c1b	2025-05-07 01:10:56.150344+08	20250411184820_add_unique_constraint_booking	\N	\N	2025-05-07 01:10:56.127093+08	1
1f5d8132-41d4-488f-91ec-ec8038beb7ea	689279bb8747bb7e9f91b05365118e56653585b5839a639c256c6c6f45c3a65f	2025-05-07 01:10:56.170397+08	20250411191853_add_user_to_booking	\N	\N	2025-05-07 01:10:56.155305+08	1
afccc214-17cf-4890-8d4d-fa23468758f7	61c686721080e5f541554ba3e144cdefece02331259912656f535a170babb94b	2025-05-12 07:08:57.467415+08	20250511230858_create_conversations_and_messages	\N	\N	2025-05-12 07:08:57.423143+08	1
182953ff-d65e-4bb6-b514-035db0c2aa4c	4f1fb77c1561335ce13fb0436973a0e2013026847b5184b1e90fc4c29870246c	2025-05-07 01:10:56.190648+08	20250412030727_add_user_to_booking_relation	\N	\N	2025-05-07 01:10:56.175732+08	1
ebd9c46d-ac79-4174-a46e-e3edc2425a84	ae0b491483281637afa10e87d4f8f42fa5e41fa6e005ab1d47cfe0b0c00d42a7	2025-05-07 01:10:56.482691+08	20250501140942_add_time_slot_relationship	\N	\N	2025-05-07 01:10:56.448265+08	1
e5e81f6e-f668-4ce2-9fb6-ced3c8e0643c	fd212b66dfaa8f4627b78fcc3465dd007af1960c2b0f7d56688ca3a19f98525a	2025-05-07 01:10:56.235475+08	20250416181121_add_shop_cache_table	\N	\N	2025-05-07 01:10:56.195444+08	1
f96eeed3-b5c1-43ec-966e-f0d162b303fc	a1dceecd134c7a230c554061c5519fa8dbbbefed15ee94e202feff235708f7c1	2025-05-07 01:10:56.278793+08	20250416190452_	\N	\N	2025-05-07 01:10:56.240428+08	1
47432c28-79c9-4c04-844a-a9382cf8639e	f5d3a53205faf846286da7651a9c0b7cfe5cce87c83725ddb75ea8f3874fb78a	2025-05-07 01:10:56.695779+08	20250506160255_add_unique_timeslot	\N	\N	2025-05-07 01:10:56.67282+08	1
35c1f7d1-ef8d-48bd-8277-3d97cd0334ec	7e7fe55e202cd2fdd66902f651a87d3863df7243a57d2240f910e2634446f57c	2025-05-07 01:10:56.298699+08	20250417060052_make_cache_expiration_optional	\N	\N	2025-05-07 01:10:56.284063+08	1
d9808fad-10eb-4d60-8a46-5de20854db66	dd7ac422578b75d38bb5b0d6730e2d99e9026af56ecfc41c0b7e8e3ccec5b0ca	2025-05-07 01:10:56.511248+08	20250501151110_add_booking_model	\N	\N	2025-05-07 01:10:56.487474+08	1
25aa60cc-c789-4ac8-a270-b55102ef1b3a	1f594340bf89fa6718e08f8249da16911456e925eabbef04a41e0353e56da60b	2025-05-07 01:10:56.335332+08	20250427191641_create_otp	\N	\N	2025-05-07 01:10:56.303375+08	1
69de5702-25e8-41e4-8ec4-ec017cfd9c63	fa8a557555b0dd5716ce9c76e780b416a4822d3628b0c88365ffe6d9ecec1243	2025-05-07 01:10:56.354758+08	20250428155744_cascade_user_otp	\N	\N	2025-05-07 01:10:56.340064+08	1
3fc0230f-9b17-4680-b7ef-bbe580490984	bd214e90ced379b3c115b484686a1e63e2d3f4493fda15c66bd08790721b5c3b	2025-05-07 01:10:56.374812+08	20250428160244_cascade_user_booking	\N	\N	2025-05-07 01:10:56.359924+08	1
9217eb4c-5474-48f2-8c23-7e72a7562538	1338b1a870ba45fd247f105f91d1426d279bed29ce099c564df7641ffaa4b5e4	2025-05-07 01:10:56.548593+08	20250501180021_adding_shop_availability	\N	\N	2025-05-07 01:10:56.516018+08	1
601e333e-5fe4-4c03-b6f7-9a653c09e6ff	fcd2110157edf32804b115d7bf338c13d0de1847958ea75eb639ad32bf732566	2025-05-12 04:49:48.051062+08	20250511204947_add_admin_log_config_models	\N	\N	2025-05-12 04:49:47.979087+08	1
37a9cae5-2796-4222-9675-261a8113ead5	91c625b30fc24af3aa94da4033135553b2672669ca7f73bdba93a2398de28fad	2025-05-07 01:10:56.568285+08	20250501182004_remove_user_id_from_shop	\N	\N	2025-05-07 01:10:56.553393+08	1
14d71887-7ba2-482b-941e-16f09ac8e3bd	d22cb8823f42d33ce7ece366c69d5c49e33109e41fdd4ed9afec4fdff35f9c35	2025-05-07 01:13:13.413937+08	20250506171312_	\N	\N	2025-05-07 01:13:13.398158+08	1
7f8e20ab-1eab-4857-a538-866f49c4bfa1	83d50b77f976ab7dcde63d6c26f5b693485ccf37402044be62993487b086d5f7	2025-05-07 01:10:56.619153+08	20250503131008_adding_bullmq_workers	\N	\N	2025-05-07 01:10:56.57289+08	1
e1157887-6c8e-4eff-b0bb-28272b1b26da	d40aabc759c999ed1474fa659691e476f41dd02dccfcca723155e3ddec60c35d	2025-05-07 01:10:56.638338+08	20250506114317_add_minute_column_to_time_slot	\N	\N	2025-05-07 01:10:56.623748+08	1
969fbc86-39fb-41fc-8dd7-68ade7eb40d1	18292cfa77e9bd77ae01edcac36f3969183a81586e54d100536a9c11d0bc0c0a	2025-05-11 23:53:20.692423+08	20250511155319_add_two_factor_secret	\N	\N	2025-05-11 23:53:20.67543+08	1
3434896b-cb12-4107-88dd-ee3832d6b476	65a11ab8ba4bf111d4383150cce6282d1068cb5b35ab0925b6c18ac3c1c23ef3	2025-05-12 05:12:06.30958+08	20250511211205_add_upload_model	\N	\N	2025-05-12 05:12:06.27485+08	1
289b604a-b897-4eea-9b95-fecf7928a056	4d90a30d73f2f1c4bec76ab531729e372c6a22d6ac8a00a28516f4fd5c36479c	2025-05-12 00:57:28.136124+08	20250511165727_add_refresh_token_to_session	\N	\N	2025-05-12 00:57:28.120611+08	1
26801934-16dc-4c22-942d-9ef41d3fec57	85c0e191b6c05d92f5e23d7fc62bdb1d1c7673dfc46435385d4094b9d6f7d7a1	2025-05-12 02:46:41.112478+08	20250511184640_add_product_model	\N	\N	2025-05-12 02:46:41.063615+08	1
8f82bde7-9562-46b8-bd9e-925e9da00d62	76b0da4938863f82f57564e64e38408f509a277873e51b00d6e0fdaf69fd5603	2025-05-12 06:25:36.261096+08	20250511222535_add_friend_request_model	\N	\N	2025-05-12 06:25:36.205268+08	1
f46f2804-ad1f-44d2-ac26-5bca7b0508c4	866a87fd89c924a08b6ed6194c1aa177d3d45c00e9c2beb76b3b73e384e76d6f	2025-05-16 22:36:27.630335+08	20250516143626_add_farm_inventory	\N	\N	2025-05-16 22:36:27.564739+08	1
5ae26645-7c27-46d6-83e0-d053ee0df665	9b054206a87b2817e70b20b8e4291b3d66052e2771a592a8cf0b384ca45abf95	2025-05-14 23:24:37.937695+08	20250514152437_add_inventory_table	\N	\N	2025-05-14 23:24:37.890291+08	1
696effe6-e0cc-497d-ac0f-68c5936ccb74	5090579f6177a046aeea72817abe0fcbf000f4e79caf10500d95966b097b1686	2025-05-15 01:18:09.442707+08	20250514171808_add_metadata_to_upload	\N	\N	2025-05-15 01:18:09.427959+08	1
d6af3a33-85c9-4711-bfc2-24f239ed0785	8146f7bd6f2f3813cf5252e2061d6adf270db5cd16380568f27d125912c1713d	2025-05-14 23:35:59.634867+08	20250514153510_connect_inventory_to_shop	\N	\N	2025-05-14 23:35:59.609351+08	1
69e51055-a806-40e6-aac8-ec39b80ce66c	87b6c416054e32e58d765779be0bf296b18038d8f2f0a4664b8a368af235ad70	2025-05-16 22:44:08.596357+08	20250516144409_inventory_unified_farm_and_shop	\N	\N	2025-05-16 22:44:08.509148+08	1
4c0c8952-5958-4d42-a76d-5e5dc372e37f	25524a6422faa4e621296c10095a89e032e4ba0073e4283930d3dc14e354605e	2025-05-16 23:53:27.828091+08	20250516155326_add_user_role	\N	\N	2025-05-16 23:53:27.812046+08	1
22c0ec85-835c-4dd3-98e3-254cb6042ee6	01bd5b770f5c1aded40829a36bbe634047a1b629b0ef131b27164464628dabcd	2025-05-17 01:12:21.261059+08	20250516171220_add_roles_model	\N	\N	2025-05-17 01:12:21.199143+08	1
\.


--
-- Name: Booking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Booking_id_seq"', 1, true);


--
-- Name: Conversation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Conversation_id_seq"', 1, true);


--
-- Name: FriendRequest_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."FriendRequest_id_seq"', 5, true);


--
-- Name: Inventory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Inventory_id_seq"', 6, true);


--
-- Name: Job_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Job_id_seq"', 1, false);


--
-- Name: Log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Log_id_seq"', 1, false);


--
-- Name: Message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Message_id_seq"', 1, false);


--
-- Name: Otp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Otp_id_seq"', 1, false);


--
-- Name: Product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Product_id_seq"', 1, false);


--
-- Name: Roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Roles_id_seq"', 1, false);


--
-- Name: Session_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Session_id_seq"', 1, true);


--
-- Name: ShopAvailability_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ShopAvailability_id_seq"', 1, true);


--
-- Name: Shop_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Shop_id_seq"', 5, true);


--
-- Name: TimeSlot_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."TimeSlot_id_seq"', 166, true);


--
-- Name: User_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."User_id_seq"', 2, true);


--
-- Name: Booking Booking_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Booking"
    ADD CONSTRAINT "Booking_pkey" PRIMARY KEY (id);


--
-- Name: Config Config_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Config"
    ADD CONSTRAINT "Config_pkey" PRIMARY KEY (key);


--
-- Name: Conversation Conversation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Conversation"
    ADD CONSTRAINT "Conversation_pkey" PRIMARY KEY (id);


--
-- Name: FriendRequest FriendRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."FriendRequest"
    ADD CONSTRAINT "FriendRequest_pkey" PRIMARY KEY (id);


--
-- Name: Inventory Inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Inventory"
    ADD CONSTRAINT "Inventory_pkey" PRIMARY KEY (id);


--
-- Name: Job Job_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Job"
    ADD CONSTRAINT "Job_pkey" PRIMARY KEY (id);


--
-- Name: Log Log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Log"
    ADD CONSTRAINT "Log_pkey" PRIMARY KEY (id);


--
-- Name: Message Message_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_pkey" PRIMARY KEY (id);


--
-- Name: Otp Otp_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Otp"
    ADD CONSTRAINT "Otp_pkey" PRIMARY KEY (id);


--
-- Name: Product Product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_pkey" PRIMARY KEY (id);


--
-- Name: Roles Roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Roles"
    ADD CONSTRAINT "Roles_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: ShopAvailability ShopAvailability_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ShopAvailability"
    ADD CONSTRAINT "ShopAvailability_pkey" PRIMARY KEY (id);


--
-- Name: Shop Shop_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Shop"
    ADD CONSTRAINT "Shop_pkey" PRIMARY KEY (id);


--
-- Name: TimeSlot TimeSlot_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TimeSlot"
    ADD CONSTRAINT "TimeSlot_pkey" PRIMARY KEY (id);


--
-- Name: Upload Upload_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Upload"
    ADD CONSTRAINT "Upload_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _UserRoles _UserRoles_AB_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_UserRoles"
    ADD CONSTRAINT "_UserRoles_AB_pkey" PRIMARY KEY ("A", "B");


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: FriendRequest_senderId_receiverId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "FriendRequest_senderId_receiverId_key" ON public."FriendRequest" USING btree ("senderId", "receiverId");


--
-- Name: Job_jobId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Job_jobId_key" ON public."Job" USING btree ("jobId");


--
-- Name: Roles_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Roles_name_key" ON public."Roles" USING btree (name);


--
-- Name: ShopAvailability_shopId_timeSlotId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ShopAvailability_shopId_timeSlotId_key" ON public."ShopAvailability" USING btree ("shopId", "timeSlotId");


--
-- Name: TimeSlot_shopId_date_hour_minute_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "TimeSlot_shopId_date_hour_minute_key" ON public."TimeSlot" USING btree ("shopId", date, hour, minute);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: _UserRoles_B_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "_UserRoles_B_index" ON public."_UserRoles" USING btree ("B");


--
-- Name: Booking Booking_availabilityId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Booking"
    ADD CONSTRAINT "Booking_availabilityId_fkey" FOREIGN KEY ("availabilityId") REFERENCES public."ShopAvailability"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Booking Booking_shopId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Booking"
    ADD CONSTRAINT "Booking_shopId_fkey" FOREIGN KEY ("shopId") REFERENCES public."Shop"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Booking Booking_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Booking"
    ADD CONSTRAINT "Booking_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: FriendRequest FriendRequest_receiverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."FriendRequest"
    ADD CONSTRAINT "FriendRequest_receiverId_fkey" FOREIGN KEY ("receiverId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: FriendRequest FriendRequest_senderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."FriendRequest"
    ADD CONSTRAINT "FriendRequest_senderId_fkey" FOREIGN KEY ("senderId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Inventory Inventory_shopId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Inventory"
    ADD CONSTRAINT "Inventory_shopId_fkey" FOREIGN KEY ("shopId") REFERENCES public."Shop"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Inventory Inventory_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Inventory"
    ADD CONSTRAINT "Inventory_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Message Message_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public."Conversation"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Otp Otp_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Otp"
    ADD CONSTRAINT "Otp_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ShopAvailability ShopAvailability_shopId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ShopAvailability"
    ADD CONSTRAINT "ShopAvailability_shopId_fkey" FOREIGN KEY ("shopId") REFERENCES public."Shop"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ShopAvailability ShopAvailability_timeSlotId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ShopAvailability"
    ADD CONSTRAINT "ShopAvailability_timeSlotId_fkey" FOREIGN KEY ("timeSlotId") REFERENCES public."TimeSlot"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: TimeSlot TimeSlot_shopId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TimeSlot"
    ADD CONSTRAINT "TimeSlot_shopId_fkey" FOREIGN KEY ("shopId") REFERENCES public."Shop"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: _UserRoles _UserRoles_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_UserRoles"
    ADD CONSTRAINT "_UserRoles_A_fkey" FOREIGN KEY ("A") REFERENCES public."Roles"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _UserRoles _UserRoles_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_UserRoles"
    ADD CONSTRAINT "_UserRoles_B_fkey" FOREIGN KEY ("B") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

