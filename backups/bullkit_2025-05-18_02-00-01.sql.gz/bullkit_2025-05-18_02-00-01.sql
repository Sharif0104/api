--
-- PostgreSQL database dump
--

-- Dumped from database version 16.8 (Ubuntu 16.8-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.8 (Ubuntu 16.8-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Booking; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Booking" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "shopId" integer NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    hour integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "availabilityId" integer NOT NULL
);


ALTER TABLE public."Booking" OWNER TO postgres;

--
-- Name: Booking_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Booking_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Booking_id_seq" OWNER TO postgres;

--
-- Name: Booking_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Booking_id_seq" OWNED BY public."Booking".id;


--
-- Name: Config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Config" (
    key text NOT NULL,
    value text NOT NULL
);


ALTER TABLE public."Config" OWNER TO postgres;

--
-- Name: Conversation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Conversation" (
    id integer NOT NULL,
    "user1Id" integer NOT NULL,
    "user2Id" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Conversation" OWNER TO postgres;

--
-- Name: Conversation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Conversation_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Conversation_id_seq" OWNER TO postgres;

--
-- Name: Conversation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Conversation_id_seq" OWNED BY public."Conversation".id;


--
-- Name: FriendRequest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."FriendRequest" (
    id integer NOT NULL,
    "senderId" integer NOT NULL,
    "receiverId" integer NOT NULL,
    status text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."FriendRequest" OWNER TO postgres;

--
-- Name: FriendRequest_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."FriendRequest_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."FriendRequest_id_seq" OWNER TO postgres;

--
-- Name: FriendRequest_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."FriendRequest_id_seq" OWNED BY public."FriendRequest".id;


--
-- Name: Friendship; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Friendship" (
    id integer NOT NULL,
    "userId1" integer NOT NULL,
    "userId2" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Friendship" OWNER TO postgres;

--
-- Name: Friendship_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Friendship_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Friendship_id_seq" OWNER TO postgres;

--
-- Name: Friendship_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Friendship_id_seq" OWNED BY public."Friendship".id;


--
-- Name: Group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Group" (
    id integer NOT NULL,
    name text NOT NULL,
    "ownerId" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Group" OWNER TO postgres;

--
-- Name: GroupMember; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."GroupMember" (
    id integer NOT NULL,
    "groupId" integer NOT NULL,
    "userId" integer NOT NULL
);


ALTER TABLE public."GroupMember" OWNER TO postgres;

--
-- Name: GroupMember_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."GroupMember_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."GroupMember_id_seq" OWNER TO postgres;

--
-- Name: GroupMember_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."GroupMember_id_seq" OWNED BY public."GroupMember".id;


--
-- Name: GroupMessage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."GroupMessage" (
    id integer NOT NULL,
    "groupId" integer NOT NULL,
    "userId" integer NOT NULL,
    content text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."GroupMessage" OWNER TO postgres;

--
-- Name: GroupMessage_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."GroupMessage_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."GroupMessage_id_seq" OWNER TO postgres;

--
-- Name: GroupMessage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."GroupMessage_id_seq" OWNED BY public."GroupMessage".id;


--
-- Name: Group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Group_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Group_id_seq" OWNER TO postgres;

--
-- Name: Group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Group_id_seq" OWNED BY public."Group".id;


--
-- Name: Inventory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Inventory" (
    id integer NOT NULL,
    name text NOT NULL,
    quantity integer NOT NULL,
    price double precision NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "shopId" integer,
    "userId" integer
);


ALTER TABLE public."Inventory" OWNER TO postgres;

--
-- Name: Inventory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Inventory_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Inventory_id_seq" OWNER TO postgres;

--
-- Name: Inventory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Inventory_id_seq" OWNED BY public."Inventory".id;


--
-- Name: Job; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Job" (
    id integer NOT NULL,
    "jobId" text NOT NULL,
    status text NOT NULL,
    result jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Job" OWNER TO postgres;

--
-- Name: Job_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Job_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Job_id_seq" OWNER TO postgres;

--
-- Name: Job_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Job_id_seq" OWNED BY public."Job".id;


--
-- Name: Log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Log" (
    id integer NOT NULL,
    message text NOT NULL,
    level text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Log" OWNER TO postgres;

--
-- Name: Log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Log_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Log_id_seq" OWNER TO postgres;

--
-- Name: Log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Log_id_seq" OWNED BY public."Log".id;


--
-- Name: Message; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Message" (
    id integer NOT NULL,
    "conversationId" integer NOT NULL,
    "userId" integer NOT NULL,
    content text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Message" OWNER TO postgres;

--
-- Name: Message_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Message_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Message_id_seq" OWNER TO postgres;

--
-- Name: Message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Message_id_seq" OWNED BY public."Message".id;


--
-- Name: Otp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Otp" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    otp text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Otp" OWNER TO postgres;

--
-- Name: Otp_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Otp_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Otp_id_seq" OWNER TO postgres;

--
-- Name: Otp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Otp_id_seq" OWNED BY public."Otp".id;


--
-- Name: Product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Product" (
    id integer NOT NULL,
    name text NOT NULL,
    price double precision NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Product" OWNER TO postgres;

--
-- Name: Product_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Product_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Product_id_seq" OWNER TO postgres;

--
-- Name: Product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Product_id_seq" OWNED BY public."Product".id;


--
-- Name: Roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Roles" (
    id integer NOT NULL,
    name text NOT NULL
);


ALTER TABLE public."Roles" OWNER TO postgres;

--
-- Name: Roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Roles_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Roles_id_seq" OWNER TO postgres;

--
-- Name: Roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Roles_id_seq" OWNED BY public."Roles".id;


--
-- Name: Session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Session" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    token text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "refreshToken" text
);


ALTER TABLE public."Session" OWNER TO postgres;

--
-- Name: Session_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Session_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Session_id_seq" OWNER TO postgres;

--
-- Name: Session_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Session_id_seq" OWNED BY public."Session".id;


--
-- Name: Shop; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Shop" (
    id integer NOT NULL,
    name text NOT NULL,
    location text NOT NULL
);


ALTER TABLE public."Shop" OWNER TO postgres;

--
-- Name: ShopAvailability; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ShopAvailability" (
    id integer NOT NULL,
    "shopId" integer NOT NULL,
    "timeSlotId" integer NOT NULL
);


ALTER TABLE public."ShopAvailability" OWNER TO postgres;

--
-- Name: ShopAvailability_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ShopAvailability_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ShopAvailability_id_seq" OWNER TO postgres;

--
-- Name: ShopAvailability_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ShopAvailability_id_seq" OWNED BY public."ShopAvailability".id;


--
-- Name: Shop_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Shop_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Shop_id_seq" OWNER TO postgres;

--
-- Name: Shop_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Shop_id_seq" OWNED BY public."Shop".id;


--
-- Name: TimeSlot; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."TimeSlot" (
    id integer NOT NULL,
    hour integer NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    "shopId" integer NOT NULL,
    minute integer NOT NULL
);


ALTER TABLE public."TimeSlot" OWNER TO postgres;

--
-- Name: TimeSlot_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."TimeSlot_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."TimeSlot_id_seq" OWNER TO postgres;

--
-- Name: TimeSlot_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."TimeSlot_id_seq" OWNED BY public."TimeSlot".id;


--
-- Name: Upload; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Upload" (
    id text NOT NULL,
    type text NOT NULL,
    path text NOT NULL,
    "originalName" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    metadata jsonb
);


ALTER TABLE public."Upload" OWNER TO postgres;

--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    id integer NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    name text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "emailVerified" boolean DEFAULT false NOT NULL,
    "twoFactorSecret" text
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Name: User_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."User_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."User_id_seq" OWNER TO postgres;

--
-- Name: User_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."User_id_seq" OWNED BY public."User".id;


--
-- Name: _UserRoles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."_UserRoles" (
    "A" integer NOT NULL,
    "B" integer NOT NULL
);


ALTER TABLE public."_UserRoles" OWNER TO postgres;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: Booking id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Booking" ALTER COLUMN id SET DEFAULT nextval('public."Booking_id_seq"'::regclass);


--
-- Name: Conversation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Conversation" ALTER COLUMN id SET DEFAULT nextval('public."Conversation_id_seq"'::regclass);


--
-- Name: FriendRequest id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."FriendRequest" ALTER COLUMN id SET DEFAULT nextval('public."FriendRequest_id_seq"'::regclass);


--
-- Name: Friendship id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Friendship" ALTER COLUMN id SET DEFAULT nextval('public."Friendship_id_seq"'::regclass);


--
-- Name: Group id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Group" ALTER COLUMN id SET DEFAULT nextval('public."Group_id_seq"'::regclass);


--
-- Name: GroupMember id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupMember" ALTER COLUMN id SET DEFAULT nextval('public."GroupMember_id_seq"'::regclass);


--
-- Name: GroupMessage id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupMessage" ALTER COLUMN id SET DEFAULT nextval('public."GroupMessage_id_seq"'::regclass);


--
-- Name: Inventory id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Inventory" ALTER COLUMN id SET DEFAULT nextval('public."Inventory_id_seq"'::regclass);


--
-- Name: Job id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Job" ALTER COLUMN id SET DEFAULT nextval('public."Job_id_seq"'::regclass);


--
-- Name: Log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Log" ALTER COLUMN id SET DEFAULT nextval('public."Log_id_seq"'::regclass);


--
-- Name: Message id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Message" ALTER COLUMN id SET DEFAULT nextval('public."Message_id_seq"'::regclass);


--
-- Name: Otp id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Otp" ALTER COLUMN id SET DEFAULT nextval('public."Otp_id_seq"'::regclass);


--
-- Name: Product id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Product" ALTER COLUMN id SET DEFAULT nextval('public."Product_id_seq"'::regclass);


--
-- Name: Roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Roles" ALTER COLUMN id SET DEFAULT nextval('public."Roles_id_seq"'::regclass);


--
-- Name: Session id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Session" ALTER COLUMN id SET DEFAULT nextval('public."Session_id_seq"'::regclass);


--
-- Name: Shop id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Shop" ALTER COLUMN id SET DEFAULT nextval('public."Shop_id_seq"'::regclass);


--
-- Name: ShopAvailability id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ShopAvailability" ALTER COLUMN id SET DEFAULT nextval('public."ShopAvailability_id_seq"'::regclass);


--
-- Name: TimeSlot id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TimeSlot" ALTER COLUMN id SET DEFAULT nextval('public."TimeSlot_id_seq"'::regclass);


--
-- Name: User id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User" ALTER COLUMN id SET DEFAULT nextval('public."User_id_seq"'::regclass);


--
-- Data for Name: Booking; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Booking" (id, "userId", "shopId", date, hour, "createdAt", "availabilityId") FROM stdin;
\.


--
-- Data for Name: Config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Config" (key, value) FROM stdin;
\.


--
-- Data for Name: Conversation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Conversation" (id, "user1Id", "user2Id", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: FriendRequest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."FriendRequest" (id, "senderId", "receiverId", status, "createdAt") FROM stdin;
\.


--
-- Data for Name: Friendship; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Friendship" (id, "userId1", "userId2", "createdAt") FROM stdin;
\.


--
-- Data for Name: Group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Group" (id, name, "ownerId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: GroupMember; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."GroupMember" (id, "groupId", "userId") FROM stdin;
\.


--
-- Data for Name: GroupMessage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."GroupMessage" (id, "groupId", "userId", content, "createdAt") FROM stdin;
\.


--
-- Data for Name: Inventory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Inventory" (id, name, quantity, price, "createdAt", "updatedAt", "shopId", "userId") FROM stdin;
\.


--
-- Data for Name: Job; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Job" (id, "jobId", status, result, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Log" (id, message, level, "createdAt") FROM stdin;
\.


--
-- Data for Name: Message; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Message" (id, "conversationId", "userId", content, "createdAt") FROM stdin;
\.


--
-- Data for Name: Otp; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Otp" (id, "userId", otp, "expiresAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Product" (id, name, price, description, "createdAt") FROM stdin;
\.


--
-- Data for Name: Roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Roles" (id, name) FROM stdin;
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Session" (id, "userId", token, "createdAt", "refreshToken") FROM stdin;
\.


--
-- Data for Name: Shop; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Shop" (id, name, location) FROM stdin;
\.


--
-- Data for Name: ShopAvailability; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ShopAvailability" (id, "shopId", "timeSlotId") FROM stdin;
\.


--
-- Data for Name: TimeSlot; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."TimeSlot" (id, hour, date, "shopId", minute) FROM stdin;
\.


--
-- Data for Name: Upload; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Upload" (id, type, path, "originalName", "createdAt", metadata) FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" (id, email, password, name, "createdAt", "emailVerified", "twoFactorSecret") FROM stdin;
\.


--
-- Data for Name: _UserRoles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."_UserRoles" ("A", "B") FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
08839e85-76ba-440b-b1a1-99e23e12d7ee	7ac4dc8d01112d135a97df68e628b718eb1a8d44a4321246b4ff1ffcb8bb0585	2025-05-18 01:29:52.560811+08	20250506142531_add_time_slot_id	\N	\N	2025-05-18 01:29:52.535268+08	1
5b82c319-41c6-4b7b-90cc-ff9cb24f3e8a	4a5679827818d9bb1b30fec2e1763627deedf4c21ed8dbf03ec90c2a2b3174e6	2025-05-18 01:29:51.923663+08	20250411153002_init	\N	\N	2025-05-18 01:29:51.877503+08	1
c6b4115a-0457-4b3f-aef1-106755a42922	834c7c93e035548d9f13148d9aa5866a186607da8f5b82ece1729a2c9fe2313b	2025-05-18 01:29:52.324674+08	20250501055014_add_session_model	\N	\N	2025-05-18 01:29:52.294211+08	1
8c9f3273-b8c1-41aa-972d-c70fb7ba9829	10dd21cf5c23d0692c2b88a2d5c0dfb11f5b7fe3fb6b1f90a0db1367523ec56b	2025-05-18 01:29:51.957655+08	20250411161110_add_shop	\N	\N	2025-05-18 01:29:51.928095+08	1
86651a2f-8647-438d-a6ec-3361ee7804a1	e76d36d6996d9ef73057dd62cdcbf7e66442c4bdc330d512428ffc6a1ba7f9cf	2025-05-18 01:29:51.995894+08	20250411181454_add_bookings_table	\N	\N	2025-05-18 01:29:51.962065+08	1
7b905f20-9afd-4cfa-9eb5-24594c8cb13e	756b0942a1e73d3233770611461b4648c2f56aef1257fac51f76fb3e643037c9	2025-05-18 01:29:52.014288+08	20250411183413_add_hour_to_booking	\N	\N	2025-05-18 01:29:52.000332+08	1
ba5d5de8-d227-44aa-8dfc-36321889ad55	36f14871b5967a04378c05986951211b19bbaf72dd21c994daff9724fad55fa8	2025-05-18 01:29:52.34331+08	20250501095951_add_email_verified	\N	\N	2025-05-18 01:29:52.329645+08	1
05f7a7bc-060a-4c28-865a-f4dfad196813	2368958c961e1597703e26023649bf73cb5041fef25b52db8bbeb1ee64fd9c1b	2025-05-18 01:29:52.042435+08	20250411184820_add_unique_constraint_booking	\N	\N	2025-05-18 01:29:52.01877+08	1
d1601f34-b4cb-4ebb-81f5-6e5e22042ccb	689279bb8747bb7e9f91b05365118e56653585b5839a639c256c6c6f45c3a65f	2025-05-18 01:29:52.091902+08	20250411191853_add_user_to_booking	\N	\N	2025-05-18 01:29:52.078366+08	1
3f8a03e1-f45d-4716-ba38-4e33f16490a9	61c686721080e5f541554ba3e144cdefece02331259912656f535a170babb94b	2025-05-18 01:29:52.861089+08	20250511230858_create_conversations_and_messages	\N	\N	2025-05-18 01:29:52.819849+08	1
76a14cb9-8f53-4209-a840-33816c651725	4f1fb77c1561335ce13fb0436973a0e2013026847b5184b1e90fc4c29870246c	2025-05-18 01:29:52.109962+08	20250412030727_add_user_to_booking_relation	\N	\N	2025-05-18 01:29:52.096278+08	1
5c8464ec-cdd3-46fe-8870-fcbbc7574187	ae0b491483281637afa10e87d4f8f42fa5e41fa6e005ab1d47cfe0b0c00d42a7	2025-05-18 01:29:52.379072+08	20250501140942_add_time_slot_relationship	\N	\N	2025-05-18 01:29:52.347701+08	1
3655d2c8-5ae1-4162-8b87-0d5b599ff3a5	fd212b66dfaa8f4627b78fcc3465dd007af1960c2b0f7d56688ca3a19f98525a	2025-05-18 01:29:52.152671+08	20250416181121_add_shop_cache_table	\N	\N	2025-05-18 01:29:52.114729+08	1
ba8a2d40-ae70-4816-b3f5-98de2dc82136	a1dceecd134c7a230c554061c5519fa8dbbbefed15ee94e202feff235708f7c1	2025-05-18 01:29:52.194689+08	20250416190452_	\N	\N	2025-05-18 01:29:52.157111+08	1
2d09bd1c-ad00-405e-8ec3-e661857ac4e5	f5d3a53205faf846286da7651a9c0b7cfe5cce87c83725ddb75ea8f3874fb78a	2025-05-18 01:29:52.587072+08	20250506160255_add_unique_timeslot	\N	\N	2025-05-18 01:29:52.565241+08	1
29c4d4ce-9295-4d87-b73e-03b923655c43	7e7fe55e202cd2fdd66902f651a87d3863df7243a57d2240f910e2634446f57c	2025-05-18 01:29:52.213361+08	20250417060052_make_cache_expiration_optional	\N	\N	2025-05-18 01:29:52.199329+08	1
97325261-b364-432a-8219-5dc9fd6b1486	dd7ac422578b75d38bb5b0d6730e2d99e9026af56ecfc41c0b7e8e3ccec5b0ca	2025-05-18 01:29:52.406707+08	20250501151110_add_booking_model	\N	\N	2025-05-18 01:29:52.383556+08	1
c461be02-ee89-45b5-b669-24d53624ab35	1f594340bf89fa6718e08f8249da16911456e925eabbef04a41e0353e56da60b	2025-05-18 01:29:52.251771+08	20250427191641_create_otp	\N	\N	2025-05-18 01:29:52.218179+08	1
f4c92252-c9cc-4373-a6f0-32d358b229f3	fa8a557555b0dd5716ce9c76e780b416a4822d3628b0c88365ffe6d9ecec1243	2025-05-18 01:29:52.270423+08	20250428155744_cascade_user_otp	\N	\N	2025-05-18 01:29:52.256556+08	1
873df381-5613-4bf2-9866-adf70bffe870	bd214e90ced379b3c115b484686a1e63e2d3f4493fda15c66bd08790721b5c3b	2025-05-18 01:29:52.289249+08	20250428160244_cascade_user_booking	\N	\N	2025-05-18 01:29:52.274851+08	1
54d7fb01-6fe1-4005-99e6-756be56b8010	1338b1a870ba45fd247f105f91d1426d279bed29ce099c564df7641ffaa4b5e4	2025-05-18 01:29:52.442674+08	20250501180021_adding_shop_availability	\N	\N	2025-05-18 01:29:52.41117+08	1
8077d91a-bc5c-44bb-b343-7d45dddadad9	fcd2110157edf32804b115d7bf338c13d0de1847958ea75eb639ad32bf732566	2025-05-18 01:29:52.729708+08	20250511204947_add_admin_log_config_models	\N	\N	2025-05-18 01:29:52.680615+08	1
3c0fcd8d-d204-4369-ae52-d287dc2cf734	91c625b30fc24af3aa94da4033135553b2672669ca7f73bdba93a2398de28fad	2025-05-18 01:29:52.46084+08	20250501182004_remove_user_id_from_shop	\N	\N	2025-05-18 01:29:52.447086+08	1
71835014-99a6-45b1-a2a2-e3e1b25f903b	d22cb8823f42d33ce7ece366c69d5c49e33109e41fdd4ed9afec4fdff35f9c35	2025-05-18 01:29:52.60527+08	20250506171312_	\N	\N	2025-05-18 01:29:52.591543+08	1
0c15f730-aad3-42b7-9b52-a3ec33daeec4	83d50b77f976ab7dcde63d6c26f5b693485ccf37402044be62993487b086d5f7	2025-05-18 01:29:52.51279+08	20250503131008_adding_bullmq_workers	\N	\N	2025-05-18 01:29:52.465682+08	1
6f541d57-7a13-40fa-99c5-affa7ca1c6de	d40aabc759c999ed1474fa659691e476f41dd02dccfcca723155e3ddec60c35d	2025-05-18 01:29:52.530661+08	20250506114317_add_minute_column_to_time_slot	\N	\N	2025-05-18 01:29:52.517198+08	1
3ff72e08-dc38-4cf2-9234-5bd13cab52ea	18292cfa77e9bd77ae01edcac36f3969183a81586e54d100536a9c11d0bc0c0a	2025-05-18 01:29:52.623398+08	20250511155319_add_two_factor_secret	\N	\N	2025-05-18 01:29:52.609693+08	1
7627b659-c591-4cec-9979-c7039db0eb7d	65a11ab8ba4bf111d4383150cce6282d1068cb5b35ab0925b6c18ac3c1c23ef3	2025-05-18 01:29:52.763668+08	20250511211205_add_upload_model	\N	\N	2025-05-18 01:29:52.734255+08	1
b177ee6d-07a9-40d5-93f7-ee9623c52cd2	4d90a30d73f2f1c4bec76ab531729e372c6a22d6ac8a00a28516f4fd5c36479c	2025-05-18 01:29:52.641498+08	20250511165727_add_refresh_token_to_session	\N	\N	2025-05-18 01:29:52.627871+08	1
2df944e0-6c02-4fe5-8f99-3464546ed639	85c0e191b6c05d92f5e23d7fc62bdb1d1c7673dfc46435385d4094b9d6f7d7a1	2025-05-18 01:29:52.676066+08	20250511184640_add_product_model	\N	\N	2025-05-18 01:29:52.646025+08	1
616f5c82-af7b-44a7-8bf7-8767e7802ff9	866a87fd89c924a08b6ed6194c1aa177d3d45c00e9c2beb76b3b73e384e76d6f	2025-05-18 01:29:52.976249+08	20250516143626_add_farm_inventory	\N	\N	2025-05-18 01:29:52.940684+08	1
f5cf9016-07e6-4d28-9078-1a7241be9ddb	76b0da4938863f82f57564e64e38408f509a277873e51b00d6e0fdaf69fd5603	2025-05-18 01:29:52.815456+08	20250511222535_add_friend_request_model	\N	\N	2025-05-18 01:29:52.768092+08	1
3875a989-8e3b-4dd4-920c-cecc420e772b	5090579f6177a046aeea72817abe0fcbf000f4e79caf10500d95966b097b1686	2025-05-18 01:29:52.936282+08	20250514171808_add_metadata_to_upload	\N	\N	2025-05-18 01:29:52.922121+08	1
6358ffd0-a0e5-4d13-8bce-ea286b6ead3d	9b054206a87b2817e70b20b8e4291b3d66052e2771a592a8cf0b384ca45abf95	2025-05-18 01:29:52.899437+08	20250514152437_add_inventory_table	\N	\N	2025-05-18 01:29:52.865878+08	1
cc3688bb-3c1e-4184-8fb6-fd8a780cac30	8146f7bd6f2f3813cf5252e2061d6adf270db5cd16380568f27d125912c1713d	2025-05-18 01:29:52.917695+08	20250514153510_connect_inventory_to_shop	\N	\N	2025-05-18 01:29:52.903822+08	1
fa67c333-5394-4100-ab90-f297f3f913eb	87b6c416054e32e58d765779be0bf296b18038d8f2f0a4664b8a368af235ad70	2025-05-18 01:29:52.995456+08	20250516144409_inventory_unified_farm_and_shop	\N	\N	2025-05-18 01:29:52.980912+08	1
dd335d0c-901e-41f3-a31f-a56f6c1c91d7	25524a6422faa4e621296c10095a89e032e4ba0073e4283930d3dc14e354605e	2025-05-18 01:29:53.013696+08	20250516155326_add_user_role	\N	\N	2025-05-18 01:29:52.999893+08	1
ba7e8fe2-7276-4d8e-9e8c-09581820db1f	01bd5b770f5c1aded40829a36bbe634047a1b629b0ef131b27164464628dabcd	2025-05-18 01:29:53.075517+08	20250516171220_add_roles_model	\N	\N	2025-05-18 01:29:53.018287+08	1
5753c66e-3b46-4fe2-8eda-bb2933c805c6	5631ec859d3f389457a0e3c23854b0b360f78d9afcbf5ff94adb3bc481203dc5	2025-05-18 01:30:45.572783+08	20250517173044_add_friendship_and_group_chat_models	\N	\N	2025-05-18 01:30:45.482661+08	1
\.


--
-- Name: Booking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Booking_id_seq"', 1, false);


--
-- Name: Conversation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Conversation_id_seq"', 1, false);


--
-- Name: FriendRequest_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."FriendRequest_id_seq"', 1, false);


--
-- Name: Friendship_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Friendship_id_seq"', 1, false);


--
-- Name: GroupMember_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."GroupMember_id_seq"', 1, false);


--
-- Name: GroupMessage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."GroupMessage_id_seq"', 1, false);


--
-- Name: Group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Group_id_seq"', 1, false);


--
-- Name: Inventory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Inventory_id_seq"', 1, false);


--
-- Name: Job_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Job_id_seq"', 1, false);


--
-- Name: Log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Log_id_seq"', 1, false);


--
-- Name: Message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Message_id_seq"', 1, false);


--
-- Name: Otp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Otp_id_seq"', 1, false);


--
-- Name: Product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Product_id_seq"', 1, false);


--
-- Name: Roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Roles_id_seq"', 1, false);


--
-- Name: Session_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Session_id_seq"', 1, false);


--
-- Name: ShopAvailability_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ShopAvailability_id_seq"', 1, false);


--
-- Name: Shop_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Shop_id_seq"', 1, false);


--
-- Name: TimeSlot_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."TimeSlot_id_seq"', 1, false);


--
-- Name: User_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."User_id_seq"', 1, false);


--
-- Name: Booking Booking_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Booking"
    ADD CONSTRAINT "Booking_pkey" PRIMARY KEY (id);


--
-- Name: Config Config_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Config"
    ADD CONSTRAINT "Config_pkey" PRIMARY KEY (key);


--
-- Name: Conversation Conversation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Conversation"
    ADD CONSTRAINT "Conversation_pkey" PRIMARY KEY (id);


--
-- Name: FriendRequest FriendRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."FriendRequest"
    ADD CONSTRAINT "FriendRequest_pkey" PRIMARY KEY (id);


--
-- Name: Friendship Friendship_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Friendship"
    ADD CONSTRAINT "Friendship_pkey" PRIMARY KEY (id);


--
-- Name: GroupMember GroupMember_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupMember"
    ADD CONSTRAINT "GroupMember_pkey" PRIMARY KEY (id);


--
-- Name: GroupMessage GroupMessage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupMessage"
    ADD CONSTRAINT "GroupMessage_pkey" PRIMARY KEY (id);


--
-- Name: Group Group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Group"
    ADD CONSTRAINT "Group_pkey" PRIMARY KEY (id);


--
-- Name: Inventory Inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Inventory"
    ADD CONSTRAINT "Inventory_pkey" PRIMARY KEY (id);


--
-- Name: Job Job_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Job"
    ADD CONSTRAINT "Job_pkey" PRIMARY KEY (id);


--
-- Name: Log Log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Log"
    ADD CONSTRAINT "Log_pkey" PRIMARY KEY (id);


--
-- Name: Message Message_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_pkey" PRIMARY KEY (id);


--
-- Name: Otp Otp_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Otp"
    ADD CONSTRAINT "Otp_pkey" PRIMARY KEY (id);


--
-- Name: Product Product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_pkey" PRIMARY KEY (id);


--
-- Name: Roles Roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Roles"
    ADD CONSTRAINT "Roles_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: ShopAvailability ShopAvailability_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ShopAvailability"
    ADD CONSTRAINT "ShopAvailability_pkey" PRIMARY KEY (id);


--
-- Name: Shop Shop_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Shop"
    ADD CONSTRAINT "Shop_pkey" PRIMARY KEY (id);


--
-- Name: TimeSlot TimeSlot_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TimeSlot"
    ADD CONSTRAINT "TimeSlot_pkey" PRIMARY KEY (id);


--
-- Name: Upload Upload_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Upload"
    ADD CONSTRAINT "Upload_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _UserRoles _UserRoles_AB_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_UserRoles"
    ADD CONSTRAINT "_UserRoles_AB_pkey" PRIMARY KEY ("A", "B");


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: FriendRequest_senderId_receiverId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "FriendRequest_senderId_receiverId_key" ON public."FriendRequest" USING btree ("senderId", "receiverId");


--
-- Name: Friendship_userId1_userId2_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Friendship_userId1_userId2_key" ON public."Friendship" USING btree ("userId1", "userId2");


--
-- Name: GroupMember_groupId_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "GroupMember_groupId_userId_key" ON public."GroupMember" USING btree ("groupId", "userId");


--
-- Name: Job_jobId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Job_jobId_key" ON public."Job" USING btree ("jobId");


--
-- Name: Roles_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Roles_name_key" ON public."Roles" USING btree (name);


--
-- Name: ShopAvailability_shopId_timeSlotId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ShopAvailability_shopId_timeSlotId_key" ON public."ShopAvailability" USING btree ("shopId", "timeSlotId");


--
-- Name: TimeSlot_shopId_date_hour_minute_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "TimeSlot_shopId_date_hour_minute_key" ON public."TimeSlot" USING btree ("shopId", date, hour, minute);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: _UserRoles_B_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "_UserRoles_B_index" ON public."_UserRoles" USING btree ("B");


--
-- Name: Booking Booking_availabilityId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Booking"
    ADD CONSTRAINT "Booking_availabilityId_fkey" FOREIGN KEY ("availabilityId") REFERENCES public."ShopAvailability"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Booking Booking_shopId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Booking"
    ADD CONSTRAINT "Booking_shopId_fkey" FOREIGN KEY ("shopId") REFERENCES public."Shop"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Booking Booking_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Booking"
    ADD CONSTRAINT "Booking_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: FriendRequest FriendRequest_receiverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."FriendRequest"
    ADD CONSTRAINT "FriendRequest_receiverId_fkey" FOREIGN KEY ("receiverId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: FriendRequest FriendRequest_senderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."FriendRequest"
    ADD CONSTRAINT "FriendRequest_senderId_fkey" FOREIGN KEY ("senderId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Friendship Friendship_userId1_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Friendship"
    ADD CONSTRAINT "Friendship_userId1_fkey" FOREIGN KEY ("userId1") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Friendship Friendship_userId2_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Friendship"
    ADD CONSTRAINT "Friendship_userId2_fkey" FOREIGN KEY ("userId2") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: GroupMember GroupMember_groupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupMember"
    ADD CONSTRAINT "GroupMember_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES public."Group"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: GroupMember GroupMember_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupMember"
    ADD CONSTRAINT "GroupMember_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: GroupMessage GroupMessage_groupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupMessage"
    ADD CONSTRAINT "GroupMessage_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES public."Group"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: GroupMessage GroupMessage_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupMessage"
    ADD CONSTRAINT "GroupMessage_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Group Group_ownerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Group"
    ADD CONSTRAINT "Group_ownerId_fkey" FOREIGN KEY ("ownerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Inventory Inventory_shopId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Inventory"
    ADD CONSTRAINT "Inventory_shopId_fkey" FOREIGN KEY ("shopId") REFERENCES public."Shop"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Inventory Inventory_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Inventory"
    ADD CONSTRAINT "Inventory_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Message Message_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public."Conversation"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Otp Otp_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Otp"
    ADD CONSTRAINT "Otp_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ShopAvailability ShopAvailability_shopId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ShopAvailability"
    ADD CONSTRAINT "ShopAvailability_shopId_fkey" FOREIGN KEY ("shopId") REFERENCES public."Shop"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ShopAvailability ShopAvailability_timeSlotId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ShopAvailability"
    ADD CONSTRAINT "ShopAvailability_timeSlotId_fkey" FOREIGN KEY ("timeSlotId") REFERENCES public."TimeSlot"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: TimeSlot TimeSlot_shopId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TimeSlot"
    ADD CONSTRAINT "TimeSlot_shopId_fkey" FOREIGN KEY ("shopId") REFERENCES public."Shop"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: _UserRoles _UserRoles_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_UserRoles"
    ADD CONSTRAINT "_UserRoles_A_fkey" FOREIGN KEY ("A") REFERENCES public."Roles"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _UserRoles _UserRoles_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_UserRoles"
    ADD CONSTRAINT "_UserRoles_B_fkey" FOREIGN KEY ("B") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

