--
-- PostgreSQL database dump
--

-- Dumped from database version 16.8 (Ubuntu 16.8-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.8 (Ubuntu 16.8-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Booking; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Booking" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "shopId" integer NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    hour integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "availabilityId" integer NOT NULL
);


ALTER TABLE public."Booking" OWNER TO postgres;

--
-- Name: Booking_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Booking_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Booking_id_seq" OWNER TO postgres;

--
-- Name: Booking_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Booking_id_seq" OWNED BY public."Booking".id;


--
-- Name: Config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Config" (
    key text NOT NULL,
    value text NOT NULL
);


ALTER TABLE public."Config" OWNER TO postgres;

--
-- Name: Conversation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Conversation" (
    id integer NOT NULL,
    "user1Id" integer NOT NULL,
    "user2Id" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Conversation" OWNER TO postgres;

--
-- Name: Conversation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Conversation_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Conversation_id_seq" OWNER TO postgres;

--
-- Name: Conversation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Conversation_id_seq" OWNED BY public."Conversation".id;


--
-- Name: FriendRequest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."FriendRequest" (
    id integer NOT NULL,
    "senderId" integer NOT NULL,
    "receiverId" integer NOT NULL,
    status text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."FriendRequest" OWNER TO postgres;

--
-- Name: FriendRequest_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."FriendRequest_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."FriendRequest_id_seq" OWNER TO postgres;

--
-- Name: FriendRequest_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."FriendRequest_id_seq" OWNED BY public."FriendRequest".id;


--
-- Name: Friendship; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Friendship" (
    id integer NOT NULL,
    "userId1" integer NOT NULL,
    "userId2" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Friendship" OWNER TO postgres;

--
-- Name: Friendship_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Friendship_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Friendship_id_seq" OWNER TO postgres;

--
-- Name: Friendship_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Friendship_id_seq" OWNED BY public."Friendship".id;


--
-- Name: GroupChat; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."GroupChat" (
    id integer NOT NULL,
    name text NOT NULL,
    "ownerId" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."GroupChat" OWNER TO postgres;

--
-- Name: GroupChatMember; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."GroupChatMember" (
    id integer NOT NULL,
    "groupChatId" integer NOT NULL,
    "userId" integer NOT NULL
);


ALTER TABLE public."GroupChatMember" OWNER TO postgres;

--
-- Name: GroupChatMember_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."GroupChatMember_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."GroupChatMember_id_seq" OWNER TO postgres;

--
-- Name: GroupChatMember_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."GroupChatMember_id_seq" OWNED BY public."GroupChatMember".id;


--
-- Name: GroupChatMessage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."GroupChatMessage" (
    id integer NOT NULL,
    "groupChatId" integer NOT NULL,
    "userId" integer NOT NULL,
    content text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."GroupChatMessage" OWNER TO postgres;

--
-- Name: GroupChatMessage_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."GroupChatMessage_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."GroupChatMessage_id_seq" OWNER TO postgres;

--
-- Name: GroupChatMessage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."GroupChatMessage_id_seq" OWNED BY public."GroupChatMessage".id;


--
-- Name: GroupChat_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."GroupChat_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."GroupChat_id_seq" OWNER TO postgres;

--
-- Name: GroupChat_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."GroupChat_id_seq" OWNED BY public."GroupChat".id;


--
-- Name: GroupMember; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."GroupMember" (
    id integer NOT NULL,
    "groupId" integer NOT NULL,
    "userId" integer NOT NULL
);


ALTER TABLE public."GroupMember" OWNER TO postgres;

--
-- Name: GroupMember_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."GroupMember_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."GroupMember_id_seq" OWNER TO postgres;

--
-- Name: GroupMember_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."GroupMember_id_seq" OWNED BY public."GroupMember".id;


--
-- Name: GroupMessage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."GroupMessage" (
    id integer NOT NULL,
    "groupId" integer NOT NULL,
    "userId" integer NOT NULL,
    content text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."GroupMessage" OWNER TO postgres;

--
-- Name: GroupMessage_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."GroupMessage_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."GroupMessage_id_seq" OWNER TO postgres;

--
-- Name: GroupMessage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."GroupMessage_id_seq" OWNED BY public."GroupMessage".id;


--
-- Name: Inventory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Inventory" (
    id integer NOT NULL,
    name text NOT NULL,
    quantity integer NOT NULL,
    price double precision NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "shopId" integer,
    "userId" integer
);


ALTER TABLE public."Inventory" OWNER TO postgres;

--
-- Name: Inventory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Inventory_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Inventory_id_seq" OWNER TO postgres;

--
-- Name: Inventory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Inventory_id_seq" OWNED BY public."Inventory".id;


--
-- Name: Job; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Job" (
    id integer NOT NULL,
    "jobId" text NOT NULL,
    status text NOT NULL,
    result jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Job" OWNER TO postgres;

--
-- Name: Job_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Job_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Job_id_seq" OWNER TO postgres;

--
-- Name: Job_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Job_id_seq" OWNED BY public."Job".id;


--
-- Name: Log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Log" (
    id integer NOT NULL,
    message text NOT NULL,
    level text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Log" OWNER TO postgres;

--
-- Name: Log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Log_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Log_id_seq" OWNER TO postgres;

--
-- Name: Log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Log_id_seq" OWNED BY public."Log".id;


--
-- Name: Message; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Message" (
    id integer NOT NULL,
    "conversationId" integer NOT NULL,
    "userId" integer NOT NULL,
    content text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Message" OWNER TO postgres;

--
-- Name: Message_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Message_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Message_id_seq" OWNER TO postgres;

--
-- Name: Message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Message_id_seq" OWNED BY public."Message".id;


--
-- Name: Otp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Otp" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    otp text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Otp" OWNER TO postgres;

--
-- Name: Otp_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Otp_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Otp_id_seq" OWNER TO postgres;

--
-- Name: Otp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Otp_id_seq" OWNED BY public."Otp".id;


--
-- Name: Product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Product" (
    id integer NOT NULL,
    name text NOT NULL,
    price double precision NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Product" OWNER TO postgres;

--
-- Name: Product_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Product_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Product_id_seq" OWNER TO postgres;

--
-- Name: Product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Product_id_seq" OWNED BY public."Product".id;


--
-- Name: Roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Roles" (
    id integer NOT NULL,
    name text NOT NULL
);


ALTER TABLE public."Roles" OWNER TO postgres;

--
-- Name: Roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Roles_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Roles_id_seq" OWNER TO postgres;

--
-- Name: Roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Roles_id_seq" OWNED BY public."Roles".id;


--
-- Name: Session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Session" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    token text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "refreshToken" text
);


ALTER TABLE public."Session" OWNER TO postgres;

--
-- Name: Session_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Session_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Session_id_seq" OWNER TO postgres;

--
-- Name: Session_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Session_id_seq" OWNED BY public."Session".id;


--
-- Name: Shop; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Shop" (
    id integer NOT NULL,
    name text NOT NULL,
    location text NOT NULL
);


ALTER TABLE public."Shop" OWNER TO postgres;

--
-- Name: ShopAvailability; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ShopAvailability" (
    id integer NOT NULL,
    "shopId" integer NOT NULL,
    "timeSlotId" integer NOT NULL
);


ALTER TABLE public."ShopAvailability" OWNER TO postgres;

--
-- Name: ShopAvailability_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ShopAvailability_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ShopAvailability_id_seq" OWNER TO postgres;

--
-- Name: ShopAvailability_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ShopAvailability_id_seq" OWNED BY public."ShopAvailability".id;


--
-- Name: Shop_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Shop_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Shop_id_seq" OWNER TO postgres;

--
-- Name: Shop_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Shop_id_seq" OWNED BY public."Shop".id;


--
-- Name: TimeSlot; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."TimeSlot" (
    id integer NOT NULL,
    hour integer NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    "shopId" integer NOT NULL,
    minute integer NOT NULL
);


ALTER TABLE public."TimeSlot" OWNER TO postgres;

--
-- Name: TimeSlot_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."TimeSlot_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."TimeSlot_id_seq" OWNER TO postgres;

--
-- Name: TimeSlot_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."TimeSlot_id_seq" OWNED BY public."TimeSlot".id;


--
-- Name: Upload; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Upload" (
    id text NOT NULL,
    type text NOT NULL,
    path text NOT NULL,
    "originalName" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    metadata jsonb
);


ALTER TABLE public."Upload" OWNER TO postgres;

--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    id integer NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    name text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "emailVerified" boolean DEFAULT false NOT NULL,
    "twoFactorSecret" text,
    "dateOfBirth" timestamp(3) without time zone NOT NULL,
    gender text NOT NULL,
    location text NOT NULL,
    "phoneNumber" text NOT NULL,
    username text NOT NULL
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Name: User_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."User_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."User_id_seq" OWNER TO postgres;

--
-- Name: User_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."User_id_seq" OWNED BY public."User".id;


--
-- Name: _UserRoles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."_UserRoles" (
    "A" integer NOT NULL,
    "B" integer NOT NULL
);


ALTER TABLE public."_UserRoles" OWNER TO postgres;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.groups (
    id integer NOT NULL,
    name text NOT NULL,
    "ownerId" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.groups OWNER TO postgres;

--
-- Name: groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.groups_id_seq OWNER TO postgres;

--
-- Name: groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.groups_id_seq OWNED BY public.groups.id;


--
-- Name: Booking id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Booking" ALTER COLUMN id SET DEFAULT nextval('public."Booking_id_seq"'::regclass);


--
-- Name: Conversation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Conversation" ALTER COLUMN id SET DEFAULT nextval('public."Conversation_id_seq"'::regclass);


--
-- Name: FriendRequest id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."FriendRequest" ALTER COLUMN id SET DEFAULT nextval('public."FriendRequest_id_seq"'::regclass);


--
-- Name: Friendship id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Friendship" ALTER COLUMN id SET DEFAULT nextval('public."Friendship_id_seq"'::regclass);


--
-- Name: GroupChat id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupChat" ALTER COLUMN id SET DEFAULT nextval('public."GroupChat_id_seq"'::regclass);


--
-- Name: GroupChatMember id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupChatMember" ALTER COLUMN id SET DEFAULT nextval('public."GroupChatMember_id_seq"'::regclass);


--
-- Name: GroupChatMessage id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupChatMessage" ALTER COLUMN id SET DEFAULT nextval('public."GroupChatMessage_id_seq"'::regclass);


--
-- Name: GroupMember id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupMember" ALTER COLUMN id SET DEFAULT nextval('public."GroupMember_id_seq"'::regclass);


--
-- Name: GroupMessage id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupMessage" ALTER COLUMN id SET DEFAULT nextval('public."GroupMessage_id_seq"'::regclass);


--
-- Name: Inventory id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Inventory" ALTER COLUMN id SET DEFAULT nextval('public."Inventory_id_seq"'::regclass);


--
-- Name: Job id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Job" ALTER COLUMN id SET DEFAULT nextval('public."Job_id_seq"'::regclass);


--
-- Name: Log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Log" ALTER COLUMN id SET DEFAULT nextval('public."Log_id_seq"'::regclass);


--
-- Name: Message id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Message" ALTER COLUMN id SET DEFAULT nextval('public."Message_id_seq"'::regclass);


--
-- Name: Otp id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Otp" ALTER COLUMN id SET DEFAULT nextval('public."Otp_id_seq"'::regclass);


--
-- Name: Product id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Product" ALTER COLUMN id SET DEFAULT nextval('public."Product_id_seq"'::regclass);


--
-- Name: Roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Roles" ALTER COLUMN id SET DEFAULT nextval('public."Roles_id_seq"'::regclass);


--
-- Name: Session id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Session" ALTER COLUMN id SET DEFAULT nextval('public."Session_id_seq"'::regclass);


--
-- Name: Shop id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Shop" ALTER COLUMN id SET DEFAULT nextval('public."Shop_id_seq"'::regclass);


--
-- Name: ShopAvailability id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ShopAvailability" ALTER COLUMN id SET DEFAULT nextval('public."ShopAvailability_id_seq"'::regclass);


--
-- Name: TimeSlot id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TimeSlot" ALTER COLUMN id SET DEFAULT nextval('public."TimeSlot_id_seq"'::regclass);


--
-- Name: User id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User" ALTER COLUMN id SET DEFAULT nextval('public."User_id_seq"'::regclass);


--
-- Name: groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.groups ALTER COLUMN id SET DEFAULT nextval('public.groups_id_seq'::regclass);


--
-- Data for Name: Booking; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Booking" (id, "userId", "shopId", date, hour, "createdAt", "availabilityId") FROM stdin;
\.


--
-- Data for Name: Config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Config" (key, value) FROM stdin;
\.


--
-- Data for Name: Conversation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Conversation" (id, "user1Id", "user2Id", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: FriendRequest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."FriendRequest" (id, "senderId", "receiverId", status, "createdAt") FROM stdin;
\.


--
-- Data for Name: Friendship; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Friendship" (id, "userId1", "userId2", "createdAt") FROM stdin;
\.


--
-- Data for Name: GroupChat; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."GroupChat" (id, name, "ownerId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: GroupChatMember; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."GroupChatMember" (id, "groupChatId", "userId") FROM stdin;
\.


--
-- Data for Name: GroupChatMessage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."GroupChatMessage" (id, "groupChatId", "userId", content, "createdAt") FROM stdin;
\.


--
-- Data for Name: GroupMember; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."GroupMember" (id, "groupId", "userId") FROM stdin;
\.


--
-- Data for Name: GroupMessage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."GroupMessage" (id, "groupId", "userId", content, "createdAt") FROM stdin;
\.


--
-- Data for Name: Inventory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Inventory" (id, name, quantity, price, "createdAt", "updatedAt", "shopId", "userId") FROM stdin;
\.


--
-- Data for Name: Job; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Job" (id, "jobId", status, result, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Log" (id, message, level, "createdAt") FROM stdin;
\.


--
-- Data for Name: Message; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Message" (id, "conversationId", "userId", content, "createdAt") FROM stdin;
\.


--
-- Data for Name: Otp; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Otp" (id, "userId", otp, "expiresAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Product" (id, name, price, description, "createdAt") FROM stdin;
\.


--
-- Data for Name: Roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Roles" (id, name) FROM stdin;
1	user
2	admin
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Session" (id, "userId", token, "createdAt", "refreshToken") FROM stdin;
\.


--
-- Data for Name: Shop; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Shop" (id, name, location) FROM stdin;
\.


--
-- Data for Name: ShopAvailability; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ShopAvailability" (id, "shopId", "timeSlotId") FROM stdin;
\.


--
-- Data for Name: TimeSlot; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."TimeSlot" (id, hour, date, "shopId", minute) FROM stdin;
\.


--
-- Data for Name: Upload; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Upload" (id, type, path, "originalName", "createdAt", metadata) FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" (id, email, password, name, "createdAt", "emailVerified", "twoFactorSecret", "dateOfBirth", gender, location, "phoneNumber", username) FROM stdin;
5	d86b144d864ae49b4481aead24c45b01:54be70e4d4e8624b4a93a0ba588fd0f804bed0fc0204bcf6398d6c234f059794	$2b$12$hP1pRQjvwkr9PIeSZ/HqCOn1wRiZvV8c4y44eiMF2I3XmNPjz06c2	Sharif Darjen Kyle E. Abdulhamid	2025-05-18 15:10:54.089	f	\N	2003-01-04 00:00:00	male	Dumaguete City, Negros Oriental	09695272245	Sharif01042003
\.


--
-- Data for Name: _UserRoles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."_UserRoles" ("A", "B") FROM stdin;
1	5
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
d6ddaa81-f64b-4f7d-a473-ceb7b3a66cf4	7ac4dc8d01112d135a97df68e628b718eb1a8d44a4321246b4ff1ffcb8bb0585	2025-05-18 22:18:37.283655+08	20250506142531_add_time_slot_id	\N	\N	2025-05-18 22:18:37.260403+08	1
ab5f3f05-36d8-49bd-9e55-fd53fb105ec4	4a5679827818d9bb1b30fec2e1763627deedf4c21ed8dbf03ec90c2a2b3174e6	2025-05-18 22:18:36.649848+08	20250411153002_init	\N	\N	2025-05-18 22:18:36.60906+08	1
391487ae-4cbf-46ed-9e3b-c97298061790	834c7c93e035548d9f13148d9aa5866a186607da8f5b82ece1729a2c9fe2313b	2025-05-18 22:18:37.031489+08	20250501055014_add_session_model	\N	\N	2025-05-18 22:18:36.994166+08	1
490f74d5-2ad6-46c1-98aa-66044da397d2	10dd21cf5c23d0692c2b88a2d5c0dfb11f5b7fe3fb6b1f90a0db1367523ec56b	2025-05-18 22:18:36.685687+08	20250411161110_add_shop	\N	\N	2025-05-18 22:18:36.654496+08	1
4b722957-244f-4575-b647-0bc13a53b267	e76d36d6996d9ef73057dd62cdcbf7e66442c4bdc330d512428ffc6a1ba7f9cf	2025-05-18 22:18:36.724176+08	20250411181454_add_bookings_table	\N	\N	2025-05-18 22:18:36.690193+08	1
a5ca6db0-4bb6-4c72-94bd-f5a37699ceb8	756b0942a1e73d3233770611461b4648c2f56aef1257fac51f76fb3e643037c9	2025-05-18 22:18:36.742958+08	20250411183413_add_hour_to_booking	\N	\N	2025-05-18 22:18:36.728785+08	1
9c68189a-f843-4b11-8acb-7e716358de22	36f14871b5967a04378c05986951211b19bbaf72dd21c994daff9724fad55fa8	2025-05-18 22:18:37.050832+08	20250501095951_add_email_verified	\N	\N	2025-05-18 22:18:37.036816+08	1
260001d7-ac07-4d1e-b0aa-f28f0c5fa5df	2368958c961e1597703e26023649bf73cb5041fef25b52db8bbeb1ee64fd9c1b	2025-05-18 22:18:36.770499+08	20250411184820_add_unique_constraint_booking	\N	\N	2025-05-18 22:18:36.747623+08	1
c15fd19e-5129-45f9-b53c-6187afe16d6c	689279bb8747bb7e9f91b05365118e56653585b5839a639c256c6c6f45c3a65f	2025-05-18 22:18:36.789706+08	20250411191853_add_user_to_booking	\N	\N	2025-05-18 22:18:36.775043+08	1
b62d3088-715c-4efa-b270-a761d10dabf6	61c686721080e5f541554ba3e144cdefece02331259912656f535a170babb94b	2025-05-18 22:18:37.592911+08	20250511230858_create_conversations_and_messages	\N	\N	2025-05-18 22:18:37.546609+08	1
c075c08e-ebfe-458e-a457-9067346ecd13	4f1fb77c1561335ce13fb0436973a0e2013026847b5184b1e90fc4c29870246c	2025-05-18 22:18:36.809543+08	20250412030727_add_user_to_booking_relation	\N	\N	2025-05-18 22:18:36.794338+08	1
04c2d9d0-25e8-4120-a8e1-a590228a870c	ae0b491483281637afa10e87d4f8f42fa5e41fa6e005ab1d47cfe0b0c00d42a7	2025-05-18 22:18:37.09507+08	20250501140942_add_time_slot_relationship	\N	\N	2025-05-18 22:18:37.05666+08	1
f98a9077-7fd8-463d-ace5-9eaeae3029e9	fd212b66dfaa8f4627b78fcc3465dd007af1960c2b0f7d56688ca3a19f98525a	2025-05-18 22:18:36.853023+08	20250416181121_add_shop_cache_table	\N	\N	2025-05-18 22:18:36.814098+08	1
efed370d-97d2-473f-9018-8de6b11427a4	a1dceecd134c7a230c554061c5519fa8dbbbefed15ee94e202feff235708f7c1	2025-05-18 22:18:36.895098+08	20250416190452_	\N	\N	2025-05-18 22:18:36.85768+08	1
7ebb23f4-6424-43a2-a83c-800e4efa8780	f5d3a53205faf846286da7651a9c0b7cfe5cce87c83725ddb75ea8f3874fb78a	2025-05-18 22:18:37.310676+08	20250506160255_add_unique_timeslot	\N	\N	2025-05-18 22:18:37.288613+08	1
48c948e5-942a-4b59-82d0-47d350c5a6c9	7e7fe55e202cd2fdd66902f651a87d3863df7243a57d2240f910e2634446f57c	2025-05-18 22:18:36.914178+08	20250417060052_make_cache_expiration_optional	\N	\N	2025-05-18 22:18:36.899719+08	1
bc5c942c-544e-423b-adb7-be7d8e718c1a	dd7ac422578b75d38bb5b0d6730e2d99e9026af56ecfc41c0b7e8e3ccec5b0ca	2025-05-18 22:18:37.123459+08	20250501151110_add_booking_model	\N	\N	2025-05-18 22:18:37.100078+08	1
9a89745b-9a6c-4f14-a613-f02fedcf06e1	1f594340bf89fa6718e08f8249da16911456e925eabbef04a41e0353e56da60b	2025-05-18 22:18:36.950099+08	20250427191641_create_otp	\N	\N	2025-05-18 22:18:36.918738+08	1
243cfc82-ec4a-4651-936b-2b3e8dcde89b	fa8a557555b0dd5716ce9c76e780b416a4822d3628b0c88365ffe6d9ecec1243	2025-05-18 22:18:36.969088+08	20250428155744_cascade_user_otp	\N	\N	2025-05-18 22:18:36.954741+08	1
dbf7d688-653e-4a25-85cc-f051c0e5898c	bd214e90ced379b3c115b484686a1e63e2d3f4493fda15c66bd08790721b5c3b	2025-05-18 22:18:36.989342+08	20250428160244_cascade_user_booking	\N	\N	2025-05-18 22:18:36.97362+08	1
7f44fdbe-85fd-4b3a-a7d0-697da9c0aea6	1338b1a870ba45fd247f105f91d1426d279bed29ce099c564df7641ffaa4b5e4	2025-05-18 22:18:37.161873+08	20250501180021_adding_shop_availability	\N	\N	2025-05-18 22:18:37.127979+08	1
cfccff6c-c2ce-4f31-a18a-6eeab62a32ea	fcd2110157edf32804b115d7bf338c13d0de1847958ea75eb639ad32bf732566	2025-05-18 22:18:37.461852+08	20250511204947_add_admin_log_config_models	\N	\N	2025-05-18 22:18:37.40863+08	1
f4d2dc0c-0096-4932-abf2-8ef9032620f4	91c625b30fc24af3aa94da4033135553b2672669ca7f73bdba93a2398de28fad	2025-05-18 22:18:37.180991+08	20250501182004_remove_user_id_from_shop	\N	\N	2025-05-18 22:18:37.166492+08	1
bca470ac-aa94-4082-a487-6c74021a406f	d22cb8823f42d33ce7ece366c69d5c49e33109e41fdd4ed9afec4fdff35f9c35	2025-05-18 22:18:37.329809+08	20250506171312_	\N	\N	2025-05-18 22:18:37.315188+08	1
1b796e0d-5c74-45a5-9fa1-eb46ab9b0334	83d50b77f976ab7dcde63d6c26f5b693485ccf37402044be62993487b086d5f7	2025-05-18 22:18:37.236685+08	20250503131008_adding_bullmq_workers	\N	\N	2025-05-18 22:18:37.185553+08	1
d551b5e8-536f-4a9d-9f98-264934b538c7	d40aabc759c999ed1474fa659691e476f41dd02dccfcca723155e3ddec60c35d	2025-05-18 22:18:37.255773+08	20250506114317_add_minute_column_to_time_slot	\N	\N	2025-05-18 22:18:37.241252+08	1
c917d9ba-e3fe-4a43-9fd4-d152496cebba	18292cfa77e9bd77ae01edcac36f3969183a81586e54d100536a9c11d0bc0c0a	2025-05-18 22:18:37.348224+08	20250511155319_add_two_factor_secret	\N	\N	2025-05-18 22:18:37.334313+08	1
c25642a5-f211-44eb-a891-3e814bbb5127	65a11ab8ba4bf111d4383150cce6282d1068cb5b35ab0925b6c18ac3c1c23ef3	2025-05-18 22:18:37.496891+08	20250511211205_add_upload_model	\N	\N	2025-05-18 22:18:37.466425+08	1
295fb3ec-bb13-4058-a854-8695618a88a9	4d90a30d73f2f1c4bec76ab531729e372c6a22d6ac8a00a28516f4fd5c36479c	2025-05-18 22:18:37.367213+08	20250511165727_add_refresh_token_to_session	\N	\N	2025-05-18 22:18:37.352961+08	1
2a6d78c0-f015-420c-9350-77b297239fc1	85c0e191b6c05d92f5e23d7fc62bdb1d1c7673dfc46435385d4094b9d6f7d7a1	2025-05-18 22:18:37.404066+08	20250511184640_add_product_model	\N	\N	2025-05-18 22:18:37.372172+08	1
153ae4ee-e383-479d-a69c-b4e913e689d2	866a87fd89c924a08b6ed6194c1aa177d3d45c00e9c2beb76b3b73e384e76d6f	2025-05-18 22:18:37.706865+08	20250516143626_add_farm_inventory	\N	\N	2025-05-18 22:18:37.671631+08	1
46816c16-6852-4654-b2b5-f52760f9b015	76b0da4938863f82f57564e64e38408f509a277873e51b00d6e0fdaf69fd5603	2025-05-18 22:18:37.541958+08	20250511222535_add_friend_request_model	\N	\N	2025-05-18 22:18:37.501495+08	1
a0c81161-96f7-4a5b-aec7-84f40ae6b1c0	5090579f6177a046aeea72817abe0fcbf000f4e79caf10500d95966b097b1686	2025-05-18 22:18:37.667062+08	20250514171808_add_metadata_to_upload	\N	\N	2025-05-18 22:18:37.653221+08	1
9daa526c-9fd8-4cf8-9920-03cd24378159	9b054206a87b2817e70b20b8e4291b3d66052e2771a592a8cf0b384ca45abf95	2025-05-18 22:18:37.629119+08	20250514152437_add_inventory_table	\N	\N	2025-05-18 22:18:37.597558+08	1
8cc92e52-82cf-409b-b1e2-e589dec20736	8146f7bd6f2f3813cf5252e2061d6adf270db5cd16380568f27d125912c1713d	2025-05-18 22:18:37.648124+08	20250514153510_connect_inventory_to_shop	\N	\N	2025-05-18 22:18:37.633706+08	1
831891b9-3332-4465-a738-ffac70c63e77	87b6c416054e32e58d765779be0bf296b18038d8f2f0a4664b8a368af235ad70	2025-05-18 22:18:37.726399+08	20250516144409_inventory_unified_farm_and_shop	\N	\N	2025-05-18 22:18:37.711398+08	1
0cb72b9b-11a2-4533-bb2a-22294352425b	25524a6422faa4e621296c10095a89e032e4ba0073e4283930d3dc14e354605e	2025-05-18 22:18:37.745297+08	20250516155326_add_user_role	\N	\N	2025-05-18 22:18:37.731313+08	1
2a3a348e-5789-4283-99bf-ad789ee03ee8	01bd5b770f5c1aded40829a36bbe634047a1b629b0ef131b27164464628dabcd	2025-05-18 22:18:37.806797+08	20250516171220_add_roles_model	\N	\N	2025-05-18 22:18:37.749913+08	1
9d7dee55-67af-43fd-b0c2-b27a4ea4d3e1	5631ec859d3f389457a0e3c23854b0b360f78d9afcbf5ff94adb3bc481203dc5	2025-05-18 22:18:37.901154+08	20250517173044_add_friendship_and_group_chat_models	\N	\N	2025-05-18 22:18:37.811422+08	1
a105c7f7-f17c-4d30-bdd3-5fbc3a01b969	7b1623e230bbf5db9c593351ecda05f2acc47400f615e278b9eadb2b1f717e40	2025-05-18 22:21:53.721125+08	20250518142152_add_username_to_user	\N	\N	2025-05-18 22:21:53.611203+08	1
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.groups (id, name, "ownerId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Name: Booking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Booking_id_seq"', 1, false);


--
-- Name: Conversation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Conversation_id_seq"', 1, false);


--
-- Name: FriendRequest_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."FriendRequest_id_seq"', 1, false);


--
-- Name: Friendship_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Friendship_id_seq"', 1, false);


--
-- Name: GroupChatMember_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."GroupChatMember_id_seq"', 1, false);


--
-- Name: GroupChatMessage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."GroupChatMessage_id_seq"', 1, false);


--
-- Name: GroupChat_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."GroupChat_id_seq"', 1, false);


--
-- Name: GroupMember_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."GroupMember_id_seq"', 1, false);


--
-- Name: GroupMessage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."GroupMessage_id_seq"', 1, false);


--
-- Name: Inventory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Inventory_id_seq"', 1, false);


--
-- Name: Job_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Job_id_seq"', 1, false);


--
-- Name: Log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Log_id_seq"', 1, false);


--
-- Name: Message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Message_id_seq"', 1, false);


--
-- Name: Otp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Otp_id_seq"', 1, false);


--
-- Name: Product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Product_id_seq"', 1, false);


--
-- Name: Roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Roles_id_seq"', 2, true);


--
-- Name: Session_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Session_id_seq"', 1, false);


--
-- Name: ShopAvailability_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ShopAvailability_id_seq"', 1, false);


--
-- Name: Shop_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Shop_id_seq"', 1, false);


--
-- Name: TimeSlot_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."TimeSlot_id_seq"', 1, false);


--
-- Name: User_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."User_id_seq"', 5, true);


--
-- Name: groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.groups_id_seq', 1, false);


--
-- Name: Booking Booking_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Booking"
    ADD CONSTRAINT "Booking_pkey" PRIMARY KEY (id);


--
-- Name: Config Config_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Config"
    ADD CONSTRAINT "Config_pkey" PRIMARY KEY (key);


--
-- Name: Conversation Conversation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Conversation"
    ADD CONSTRAINT "Conversation_pkey" PRIMARY KEY (id);


--
-- Name: FriendRequest FriendRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."FriendRequest"
    ADD CONSTRAINT "FriendRequest_pkey" PRIMARY KEY (id);


--
-- Name: Friendship Friendship_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Friendship"
    ADD CONSTRAINT "Friendship_pkey" PRIMARY KEY (id);


--
-- Name: GroupChatMember GroupChatMember_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupChatMember"
    ADD CONSTRAINT "GroupChatMember_pkey" PRIMARY KEY (id);


--
-- Name: GroupChatMessage GroupChatMessage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupChatMessage"
    ADD CONSTRAINT "GroupChatMessage_pkey" PRIMARY KEY (id);


--
-- Name: GroupChat GroupChat_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupChat"
    ADD CONSTRAINT "GroupChat_pkey" PRIMARY KEY (id);


--
-- Name: GroupMember GroupMember_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupMember"
    ADD CONSTRAINT "GroupMember_pkey" PRIMARY KEY (id);


--
-- Name: GroupMessage GroupMessage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupMessage"
    ADD CONSTRAINT "GroupMessage_pkey" PRIMARY KEY (id);


--
-- Name: Inventory Inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Inventory"
    ADD CONSTRAINT "Inventory_pkey" PRIMARY KEY (id);


--
-- Name: Job Job_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Job"
    ADD CONSTRAINT "Job_pkey" PRIMARY KEY (id);


--
-- Name: Log Log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Log"
    ADD CONSTRAINT "Log_pkey" PRIMARY KEY (id);


--
-- Name: Message Message_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_pkey" PRIMARY KEY (id);


--
-- Name: Otp Otp_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Otp"
    ADD CONSTRAINT "Otp_pkey" PRIMARY KEY (id);


--
-- Name: Product Product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_pkey" PRIMARY KEY (id);


--
-- Name: Roles Roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Roles"
    ADD CONSTRAINT "Roles_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: ShopAvailability ShopAvailability_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ShopAvailability"
    ADD CONSTRAINT "ShopAvailability_pkey" PRIMARY KEY (id);


--
-- Name: Shop Shop_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Shop"
    ADD CONSTRAINT "Shop_pkey" PRIMARY KEY (id);


--
-- Name: TimeSlot TimeSlot_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TimeSlot"
    ADD CONSTRAINT "TimeSlot_pkey" PRIMARY KEY (id);


--
-- Name: Upload Upload_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Upload"
    ADD CONSTRAINT "Upload_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _UserRoles _UserRoles_AB_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_UserRoles"
    ADD CONSTRAINT "_UserRoles_AB_pkey" PRIMARY KEY ("A", "B");


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: FriendRequest_senderId_receiverId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "FriendRequest_senderId_receiverId_key" ON public."FriendRequest" USING btree ("senderId", "receiverId");


--
-- Name: Friendship_userId1_userId2_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Friendship_userId1_userId2_key" ON public."Friendship" USING btree ("userId1", "userId2");


--
-- Name: GroupChatMember_groupChatId_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "GroupChatMember_groupChatId_userId_key" ON public."GroupChatMember" USING btree ("groupChatId", "userId");


--
-- Name: GroupMember_groupId_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "GroupMember_groupId_userId_key" ON public."GroupMember" USING btree ("groupId", "userId");


--
-- Name: Job_jobId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Job_jobId_key" ON public."Job" USING btree ("jobId");


--
-- Name: Roles_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Roles_name_key" ON public."Roles" USING btree (name);


--
-- Name: ShopAvailability_shopId_timeSlotId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ShopAvailability_shopId_timeSlotId_key" ON public."ShopAvailability" USING btree ("shopId", "timeSlotId");


--
-- Name: TimeSlot_shopId_date_hour_minute_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "TimeSlot_shopId_date_hour_minute_key" ON public."TimeSlot" USING btree ("shopId", date, hour, minute);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_phoneNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_phoneNumber_key" ON public."User" USING btree ("phoneNumber");


--
-- Name: User_username_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_username_key" ON public."User" USING btree (username);


--
-- Name: _UserRoles_B_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "_UserRoles_B_index" ON public."_UserRoles" USING btree ("B");


--
-- Name: Booking Booking_availabilityId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Booking"
    ADD CONSTRAINT "Booking_availabilityId_fkey" FOREIGN KEY ("availabilityId") REFERENCES public."ShopAvailability"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Booking Booking_shopId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Booking"
    ADD CONSTRAINT "Booking_shopId_fkey" FOREIGN KEY ("shopId") REFERENCES public."Shop"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Booking Booking_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Booking"
    ADD CONSTRAINT "Booking_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: FriendRequest FriendRequest_receiverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."FriendRequest"
    ADD CONSTRAINT "FriendRequest_receiverId_fkey" FOREIGN KEY ("receiverId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: FriendRequest FriendRequest_senderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."FriendRequest"
    ADD CONSTRAINT "FriendRequest_senderId_fkey" FOREIGN KEY ("senderId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Friendship Friendship_userId1_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Friendship"
    ADD CONSTRAINT "Friendship_userId1_fkey" FOREIGN KEY ("userId1") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Friendship Friendship_userId2_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Friendship"
    ADD CONSTRAINT "Friendship_userId2_fkey" FOREIGN KEY ("userId2") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: GroupChatMember GroupChatMember_groupChatId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupChatMember"
    ADD CONSTRAINT "GroupChatMember_groupChatId_fkey" FOREIGN KEY ("groupChatId") REFERENCES public."GroupChat"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: GroupChatMember GroupChatMember_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupChatMember"
    ADD CONSTRAINT "GroupChatMember_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: GroupChatMessage GroupChatMessage_groupChatId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupChatMessage"
    ADD CONSTRAINT "GroupChatMessage_groupChatId_fkey" FOREIGN KEY ("groupChatId") REFERENCES public."GroupChat"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: GroupChatMessage GroupChatMessage_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupChatMessage"
    ADD CONSTRAINT "GroupChatMessage_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: GroupChat GroupChat_ownerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupChat"
    ADD CONSTRAINT "GroupChat_ownerId_fkey" FOREIGN KEY ("ownerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: GroupMember GroupMember_groupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupMember"
    ADD CONSTRAINT "GroupMember_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES public.groups(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: GroupMember GroupMember_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupMember"
    ADD CONSTRAINT "GroupMember_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: GroupMessage GroupMessage_groupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupMessage"
    ADD CONSTRAINT "GroupMessage_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES public.groups(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: GroupMessage GroupMessage_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupMessage"
    ADD CONSTRAINT "GroupMessage_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Inventory Inventory_shopId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Inventory"
    ADD CONSTRAINT "Inventory_shopId_fkey" FOREIGN KEY ("shopId") REFERENCES public."Shop"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Inventory Inventory_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Inventory"
    ADD CONSTRAINT "Inventory_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Message Message_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public."Conversation"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Otp Otp_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Otp"
    ADD CONSTRAINT "Otp_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ShopAvailability ShopAvailability_shopId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ShopAvailability"
    ADD CONSTRAINT "ShopAvailability_shopId_fkey" FOREIGN KEY ("shopId") REFERENCES public."Shop"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ShopAvailability ShopAvailability_timeSlotId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ShopAvailability"
    ADD CONSTRAINT "ShopAvailability_timeSlotId_fkey" FOREIGN KEY ("timeSlotId") REFERENCES public."TimeSlot"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: TimeSlot TimeSlot_shopId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TimeSlot"
    ADD CONSTRAINT "TimeSlot_shopId_fkey" FOREIGN KEY ("shopId") REFERENCES public."Shop"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: _UserRoles _UserRoles_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_UserRoles"
    ADD CONSTRAINT "_UserRoles_A_fkey" FOREIGN KEY ("A") REFERENCES public."Roles"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _UserRoles _UserRoles_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_UserRoles"
    ADD CONSTRAINT "_UserRoles_B_fkey" FOREIGN KEY ("B") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: groups groups_ownerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT "groups_ownerId_fkey" FOREIGN KEY ("ownerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

